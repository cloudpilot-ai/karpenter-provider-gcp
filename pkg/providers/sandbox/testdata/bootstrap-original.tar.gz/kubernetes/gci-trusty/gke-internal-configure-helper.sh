#!/bin/bash

# Functions and vars copied from configure.sh
# --- BEGIN ---
CURL_FLAGS=(
  '--fail'
  '--silent'
  '--show-error'
  '--retry' '5'
  '--retry-delay' '3'
  '--connect-timeout' '10'
  '--retry-connrefused'
)
GCE_METADATA_INTERNAL="http://metadata.google.internal/computeMetadata/v1/instance"
function get-credentials {
  curl "${CURL_FLAGS[@]}" \
    -H "Metadata-Flavor: Google" \
    "${GCE_METADATA_INTERNAL}/service-accounts/default/token" \
  | python3 -c 'import sys; import json; print(json.loads(sys.stdin.read())["access_token"])'
}

if [[ "${KUBERNETES_MASTER:-}" == "true" ]]; then
  if [[ "${IS_PRELOADER:-}" != "true" ]] &&\
    grep -qs "PRELOADED," "${KUBE_HOME}/preload_info" &&\
    [[ $(get-metadata-value "instance/attributes/fail-on-artifact-mismatch" "false") == "true" ]]; then
      # Disallow artifact downloads when:
      # - running on master VMs
      # - && not in preloader (running in bootstrap)
      # - && VM image is preloaded
      # - && failure on artifact mismatch feature is enabled
      ARTIFACT_DOWNLOAD_RESTRICTED="true"
  fi
fi
# --- END ---

# Returns TLS SNI param for kube-apiserver.
function gke-kube-apiserver-internal-sni-param {
  if [[ "${KUBE_APISERVER_TLS_VERIFY_ENABLED:-}" == "true" ]]; then
    if [[ -z "${KUBE_APISERVER_SERVER_INTERNAL_CERT_PATH}" || -z "${KUBE_APISERVER_SERVER_INTERNAL_KEY_PATH}" || -z "${KUBE_APISERVER_INTERNAL_ADDRESS}" ]]; then
      echo "Error: TLS verification is enabled, but KUBE_APISERVER_SERVER_INTERNAL_CERT_PATH or KUBE_APISERVER_SERVER_INTERNAL_KEY_PATH or KUBE_APISERVER_INTERNAL_ADDRESS is missing in env var."
      exit 1
    fi

    echo " --tls-sni-cert-key=${KUBE_APISERVER_SERVER_INTERNAL_CERT_PATH},${KUBE_APISERVER_SERVER_INTERNAL_KEY_PATH}:${KUBE_APISERVER_INTERNAL_ADDRESS}"
  fi
}

# Writes a cert/key pair for kube-apiserver to server TLS on a GKE internal address.
function write-kube-apiserver-internal-cert-key {
  if [[ "${KUBE_APISERVER_TLS_VERIFY_ENABLED:-}" == "true" ]]; then
    if [[ -z "${KUBE_APISERVER_INTERNAL_TLS_CERT}" || -z "${KUBE_APISERVER_INTERNAL_TLS_KEY}" ]]; then
      echo "Error: TLS verification is enabled, but KUBE_APISERVER_INTERNAL_TLS_CERT or KUBE_APISERVER_INTERNAL_TLS_KEY is missing in env var."
      exit 1
    fi

    local -r pki_dir="/etc/srv/kubernetes/pki"
    mkdir -p "${pki_dir}"

    KUBE_APISERVER_SERVER_INTERNAL_CERT_PATH="${pki_dir}/internal-apiserver.crt"
    write-pki-data "${KUBE_APISERVER_INTERNAL_TLS_CERT}" "${KUBE_APISERVER_SERVER_INTERNAL_CERT_PATH}"
    KUBE_APISERVER_SERVER_INTERNAL_KEY_PATH="${pki_dir}/internal-apiserver.key"
    write-pki-data "${KUBE_APISERVER_INTERNAL_TLS_KEY}" "${KUBE_APISERVER_SERVER_INTERNAL_KEY_PATH}"
  fi
}

function dcd-overwrite-kube-apiserver-internal-cert-paths {
  echo "Loading Dynamic Cert Delivery internal kube-apiserver cert vars."
  KUBE_APISERVER_SERVER_INTERNAL_CERT_PATH=${DCD_KUBE_APISERVER_SERVER_INTERNAL_CERT_PATH}
  KUBE_APISERVER_SERVER_INTERNAL_KEY_PATH=${DCD_KUBE_APISERVER_SERVER_INTERNAL_KEY_PATH}
}

# Add entry to hostfile to redirect internal name to master internal IP.
function setup-kube-apiserver-internal-address-redirect {
  if [[ "${KUBE_APISERVER_TLS_VERIFY_ENABLED:-}" == "true" ]]; then
    if [[ -z "${KUBE_APISERVER_INTERNAL_ADDRESS}" ]]; then
      echo "Error: TLS verification is enabled, but KUBE_APISERVER_INTERNAL_ADDRESS is missing in env var."
      exit 1
    fi

    local internal_ip
    internal_ip=$(ifconfig eth0 | grep 'inet ' | awk '{print $2}')
    echo "Master IPv4 internal IP is ${internal_ip}"
    echo "${internal_ip} ${KUBE_APISERVER_INTERNAL_ADDRESS}" >>/etc/hosts
  fi
}

function start_internal_cluster_autoscaler {
  if [[ "${ENABLE_NAP:-}" == "true" || "${ENABLE_GKE_CLUSTER_AUTOSCALER:-}" == "true" ]]; then
    echo "Error: Requested NAP or cluster autoscaler, which should be configured via CRP. ENABLE_NAP=${ENABLE_NAP}, ENABLE_GKE_CLUSTER_AUTOSCALER=${ENABLE_GKE_CLUSTER_AUTOSCALER}"
    exit 1
  fi
}

function add_vpa_admission_webhook_host {
  original_ipv6_loopback_line=$(grep "^::1[[:space:]]" /etc/hosts)
  tmp_file=$(mktemp)
  grep -v "^::1[[:space:]]" /etc/hosts >"${tmp_file}"
  cat "${tmp_file}" >/etc/hosts
  if [[ -n "${original_ipv6_loopback_line:-}" ]]; then
    echo "${original_ipv6_loopback_line} vpa.admissionwebhook.localhost" >>/etc/hosts
  else
    echo "::1 vpa.admissionwebhook.localhost" >>/etc/hosts
  fi
}

function start_pod_autoscaler {
  local -r manifests_dir="${KUBE_HOME}/kube-manifests/kubernetes/gci-trusty"
  mkdir -p "${manifests_dir}/pod-autoscaler"
  if [[ "${ENABLE_VERTICAL_POD_AUTOSCALER:-}" == "true" ]]; then
    echo "Start Vertical Pod Autoscaler (VPA)"
    generate_vertical_pod_autoscaler_admission_controller_certs
    add_vpa_admission_webhook_host

    cp "${manifests_dir}/internal-vpa-crd.yaml" "${manifests_dir}/pod-autoscaler"
    cp "${manifests_dir}/internal-vpa-rbac.yaml" "${manifests_dir}/pod-autoscaler"
    if [[ "${ENABLE_MULTIDIM_POD_AUTOSCALER:-}" == "true" ]]; then
      cp "${manifests_dir}/internal-mpa-crd.yaml" "${manifests_dir}/pod-autoscaler"
      cp "${manifests_dir}/internal-mpa-rbac.yaml" "${manifests_dir}/pod-autoscaler"
    fi
    setup-addon-manifests "addons" "pod-autoscaler"

    for component in admission-controller recommender updater; do
      setup_pod_autoscaler_component "${component}" "${manifests_dir}"
    done
  elif [[ "${ENABLE_UNIFIED_AUTOSCALING:-}" == "true" ]]; then
    cp "${manifests_dir}/internal-kuba-rbac.yaml" "${manifests_dir}/pod-autoscaler"
    setup-addon-manifests "addons" "pod-autoscaler"

    echo "Start Kubernetes Adapter for Unified Autoscaler (KUBA)"
    setup_pod_autoscaler_component "recommender" "${manifests_dir}"
  fi
}

function base64_decode_or_die {
  local variable_name=$1
  local out_file=$2
  if [[ -n "${!variable_name}" ]]; then
    if ! base64 -d - <<<"${!variable_name}" >"${out_file}"; then
      echo "==error base 64 decoding ${variable_name}=="
      echo "==the value of the variable is ${!variable_name}=="
      exit 1
    fi
  else
    echo "==VPA enabled but ${variable_name} is not set=="
    exit 1
  fi
}

function setup_pod_autoscaler_component {
  local component=$1
  local manifests_dir=$2
  create-static-auth-kubeconfig-for-component "vpa-${component}"

  # Prepare manifest
  local src_file="${manifests_dir}/internal-vpa-${component}.manifest"

  if [[ ${component} == "recommender" ]]; then
    local uas_params="${UAS_PARAMS:-}"
    # split the params into separate arguments passed to binary
    local uas_params_split
    uas_params_split=$(eval "for param in $uas_params; do echo -n ,\\\"\$param\\\"; done")
    sed -i -e "s@{{uas_params}}@${uas_params_split:-}@g" "${src_file}"

    # set memory limit for vpa-recommender. Limit default value
    # justification in http://b/163760835#comment8
    local memory_limit="${POD_AUTOSCALER_MEMORY_LIMIT:-4Gi}"
    sed -i -e "s@{{memory_limit}}@${memory_limit}@g" "${src_file}"
  fi

  sed -i -e "s@{{cloud_config_mount}}@${CLOUD_CONFIG_MOUNT}@g" "${src_file}"
  sed -i -e "s@{{cloud_config_volume}}@${CLOUD_CONFIG_VOLUME}@g" "${src_file}"
  sed -i -e "s@{%.*%}@@g" "${src_file}"

  cp "${src_file}" /etc/kubernetes/manifests
}

function generate_vertical_pod_autoscaler_admission_controller_certs {
  local certs_dir="/etc/tls-certs" #TODO: what is the best place for certs?
  echo "Generating certs for the VPA Admission Controller in ${certs_dir}."
  mkdir -p ${certs_dir}
  if [[ -n "${CA_CERT:-}" ]] && [[ -n "${VPA_AC_KEY:-}" ]] && [[ -n "${VPA_AC_CERT:-}" ]]; then
    base64_decode_or_die "CA_CERT" ${certs_dir}/caCert.pem
    base64_decode_or_die "VPA_AC_KEY" ${certs_dir}/serverKey.pem
    base64_decode_or_die "VPA_AC_CERT" ${certs_dir}/serverCert.pem
  else
    echo "==At least one of CA_CERT, VPA_AC_KEY, VPA_AC_CERT is missing=="
    exit 1
  fi
}

function setup_master_prom_to_sd_monitor_component {
  local -r manifests_dir="${KUBE_HOME}/kube-manifests/kubernetes/gci-trusty"
  mkdir -p "${manifests_dir}/master-prom-to-sd-monitor"

  cp "${manifests_dir}/internal-master-prom-to-sd-monitor-rbac.yaml" "${manifests_dir}/master-prom-to-sd-monitor"
  setup-addon-manifests "addons" "master-prom-to-sd-monitor"

  create-static-auth-kubeconfig-for-component master-prom-to-sd-monitor
}

function create-static-auth-kubeconfig-for-component {
  local component=$1
  echo "Creating token for component ${component}"
  local token
  token="$(secure_random 32)"
  append_or_replace_prefixed_line /etc/srv/kubernetes/known_tokens.csv "${token}," "system:${component},uid:system:${component}${AUTH_COMPONENTS_GROUP:+,$AUTH_COMPONENTS_GROUP}"
  create-kubeconfig "${component}" "${token}"
  echo -n "${token}" > /etc/srv/kubernetes/"${component}"/token
}

function gke-internal-master-start {
  echo "Internal GKE configuration start"
  compute-master-manifest-variables

  write-kube-apiserver-internal-cert-key
  if [[ "${ENABLE_KCP_DYNAMIC_CERTIFICATE_DELIVERY:-}" = "true" ]]; then
    # If DCD is enabled, overwrites the "internal" kube-apiserver serving cert
    # paths to ones set by DCD.
    dcd-overwrite-kube-apiserver-internal-cert-paths
  fi
  setup-kube-apiserver-internal-address-redirect

  start_internal_cluster_autoscaler
  start_pod_autoscaler
  setup_master_prom_to_sd_monitor_component
  if generate-token-for-mastertest; then
    create-static-auth-kubeconfig-for-component mastertest
  fi

  if [[ "${LOCAL_ADMIN_GKE_EXEC_AUTH:-false}" == "true" ]] && [[ -n "${TOKEN_URL:-}" ]] && [[ -n "${TOKEN_BODY_UNQUOTED:-}" ]]; then
    echo "setting up local admin kubeconfig with gke-exec-auth-plugin"
    create-kcp-admin-kubeconfig
    echo "export KUBECONFIG=/etc/srv/kubernetes/local-admin/kubeconfig" > /etc/profile.d/kubeconfig.sh
  elif [[ -n "${KUBE_BEARER_TOKEN:-}" ]]; then
    echo "setting up local admin kubeconfig"
    create-kubeconfig "local-admin" "${KUBE_BEARER_TOKEN}"
    echo "export KUBECONFIG=/etc/srv/kubernetes/local-admin/kubeconfig" > /etc/profile.d/kubeconfig.sh
  fi

  echo "Internal GKE configuration done"
}

# Configure the node kernel parameters.
#
# This function expects no arguments.
#
# This function
#   - Reads the kernel parameter default values from release artifacts and the
#     overrides from SYSCTL_OVERRIDES, generates the sysctl conf files under
#     /etc/sysctl.d/, and applies them using systemd-sysctl.
#   - Sets the variable POD_SYSCTLS with the namespaced GKE fleetwide kernel
#     parameters and the user overrides. The variable is expected to be read
#     by the start-kubelet function.
function gke-configure-node-sysctls {
  local -r dir="${KUBE_HOME}/kube-manifests/kubernetes/gci-trusty/sysctl"
  # sysctl_overrides - list of sysctls supplied from GKE control plane to
  # override default sysctls for host namespace (supplied by user).
  local -r sysctl_overrides="${SYSCTL_OVERRIDES:-}"
  # pod_sysctl_overrides - list of sysctls supplied from GKE control plane to
  # override default sysctls in pod namespaces. Note that sysctl_overrides
  # will take precedence over this.
  local -r pod_sysctl_overrides="${EXTRA_POD_SYSCTLS:-}"
  local -r namespaced_sysctl_names="${dir}/namespaced-sysctl-names.yaml"
  # Use the GKE fleetwide default values if ENABLE_SYSCTL_TUNING is "true".
  if [[ "${ENABLE_SYSCTL_TUNING:-}" == "true" ]]; then
    local -r sysctl_defaults="${dir}/sysctl-defaults.yaml"
  else
    local -r sysctl_defaults="/dev/null"
  fi

  local -r conf_dir="/etc/sysctl.d"
  # The overrides must be applied after the defaults. This is guaranteed by
  # the alphabetical order of the file names.
  #
  # It's guaranteed that 99-sysctl.conf is the only file that comes after
  # 99-gke-defaults.conf and 99-gke-overrides.conf in the current sysctl config
  # layout on COS and Ubuntu.
  #
  # On both images, 99-sysctl.conf is a symlink to /etc/sysctl.conf, which
  # contains no settings.
  #
  # TODO(b/131158180): Allow GKE to provide sysctl config files in a more
  # reliable way by renaming the existing 99-*.conf files to 8x-*.conf.
  local -r output_defaults="${conf_dir}/99-gke-defaults.conf"
  local -r output_overrides="${conf_dir}/99-gke-overrides.conf"

  # Create the directory in case it doesn't exist.
  mkdir -p "${conf_dir}"

  echo "Sysctl overrides: ${sysctl_overrides}"

  # Generate the kernel parameter defaults and overrides configs in
  # /etc/sysctl.d/. They will be loaded by systemd-sysctl on reboot.
  python3 "${dir}/generate-conf-files.py" \
    --sysctl-defaults="${sysctl_defaults}" \
    --sysctl-overrides="${sysctl_overrides}" \
    --output-defaults=${output_defaults} \
    --output-overrides=${output_overrides}

  echo "Pod sysctl overrides: ${pod_sysctl_overrides}"

  # Extract the namespaced kernel parameter defaults and overrides that should
  # be passed to kubelet and set inside pod namespaces.
  POD_SYSCTLS=$(python3 "${dir}/extract-namespaced.py" \
    --sysctl-defaults="${sysctl_defaults}" \
    --sysctl-overrides="${sysctl_overrides}" \
    --pod-sysctl-overrides="${pod_sysctl_overrides}" \
    --namespaced-sysctl-names="${namespaced_sysctl_names}")

  echo "Sysctls to be set in pod namespaces: ${POD_SYSCTLS}"

  # Run systemd-sysctl to apply the kernel parameters on node.
  if [[ -e "/usr/lib/systemd/systemd-sysctl" ]]; then
    /usr/lib/systemd/systemd-sysctl
  else
    /lib/systemd/systemd-sysctl
  fi

  # Take a snapshot of the current sysctls and store them in a file. This will
  # be used as the base for monitoring sysctl changes by NPD custom plugin
  # sysctl-monitor.
  #
  # The directory was created in configure.sh.
  sysctl -a > "${KUBE_HOME}/npd-custom-plugins/configs/init-sysctls.conf"
}

function detect_mtu {
  local MTU=1460
  if [[ "${DETECT_MTU:-}" == "true" ]];then
    local default_nic
    default_nic=$(ip route get 8.8.8.8 | sed -nr "s/.*dev ([^\ ]+).*/\1/p")
    if [ -f "/sys/class/net/$default_nic/mtu" ]; then
      MTU=$(cat "/sys/class/net/$default_nic/mtu")
    fi
  fi
  echo "$MTU"
}

function _gke_cni_template {
  local MTU
  MTU="$(detect_mtu)"
  cat <<EOF
{
  "name": "k8s-pod-network",
  "cniVersion": "0.3.1",
  "plugins": [
    {
      "type": "ptp",
      "mtu": ${MTU},
      "ipam": {
        "type": "host-local",
        "subnet": "{{.PodCIDR}}",
        "routes": [
          {
            "dst": "0.0.0.0/0"
          }
        ]
      }
    },
    {
      "type": "portmap",
      "capabilities": {
        "portMappings": true
      }
    }
  ]
}
EOF
}

# Default containerd config TOML file
CONTAINERD_CONFIG_FILE="/etc/containerd/config.toml"
# Directory containing $CONTAINERD_CONFIG_FILE
CONTAINERD_CONFIG_ROOT=$(dirname "${CONTAINERD_CONFIG_FILE}")
# Directory containing domain-specific config for containerd CRI
# registry hostpath
CONTAINERD_CRI_REGISTRY_HOSTPATH_CONFIG_ROOT="${CONTAINERD_CONFIG_ROOT}/hosts.d"
# Directory containing certificates for containerd CRI registry hostpath
CONTAINERD_CRI_REGISTRY_HOSTPATH_CERTS_ROOT="${CONTAINERD_CONFIG_ROOT}/certs.d"
# GSM API URL
# TODO(b/283980355): define an override mechanism for TPC
GSM_ENDPOINT="https://secretmanager.googleapis.com"
# Default file names for private CA certificate
PRIVATE_CA_CRT_NAME="ca.crt"
# Default file names for private CA certificate metadata
PRIVATE_CA_CRT_METADATA_NAME="metadata.json"

# Downloads and installs a CA certificate from Google Secret Manager (GSM).
# On successful download, it will install the certificate under
# containerd_certs_dir/cert_url/ca.crt, as well as the secret metadata under
# containerd_certs_dir/cert_url/metadata.json.
# This function extract HTTP error codes to distinguish between user errors
# (e.g. typos, access config errors) and system errors (e.g. GSM outage).
function install-gsm-certificate() {
  local -r cert_url="${1:-}"
  if [[ -z "${cert_url}" ]]; then
    echo "Certificate URL must be specified"
    return 1
  fi
  local -r cert_dir="${2:-}"
  if [[ -z "${cert_dir}" ]]; then
    echo "Certificate directory must be specified"
    return 1
  fi
  local -r token="$(get-credentials)"
  if [[ -z "${token}" ]]; then
    echo "Failed to get credentials from metadata server"
    return 1
  fi
  local -r curl_headers="Authorization: Bearer ${token}"
  local -r api_url="${GSM_ENDPOINT}/v1/${cert_url}"
  local -r payload_file="/tmp/gsm-payload.json"
  local -r gsm_curl_flags=("${CURL_FLAGS[@]}" -H "${curl_headers}" -Lo "${payload_file}")
  local curl_error http_code

  if ! curl_error=$(curl "${gsm_curl_flags[@]}" "${api_url}" 2>&1); then
    http_code=$(echo "${curl_error}" | sed -nE 's/^.*([0-9]{3})$/\1/p')
    if (( http_code >= 400 && http_code <= 499 )); then
      echo "User error pulling certificate metadata \"${cert_url}\" from GSM, code: ${http_code}."
    elif (( http_code >= 500 )); then
      echo "Internal error pulling certificate metadata \"${cert_url}\" from GSM, code: ${http_code}."
    else
      echo "Internal error pulling certificate metadata \"${cert_url}\" from GSM: ${curl_error}"
    fi
    return 1
  fi
  local -r metadata_file="${cert_dir}/${PRIVATE_CA_CRT_METADATA_NAME}"
  mv "${payload_file}" "${metadata_file}"
  chmod 444 "${metadata_file}"

  if ! curl_error=$(curl "${gsm_curl_flags[@]}" "$api_url:access" 2>&1); then
    http_code=$(echo "$curl_error" | sed -nE 's/^.*([0-9]{3})$/\1/p')
    if (( http_code >= 400 && http_code <= 499 )); then
      echo "User error pulling certificate \"${cert_url}\" from GSM, code: ${http_code}."
    elif (( http_code >= 500 )); then
      echo "Internal error pulling certificate \"${cert_url}\" from GSM, code: ${http_code}."
    else
      echo "Internal error pulling certificate \"${cert_url}\" from GSM: ${curl_error}"
    fi
    return 1
  fi
  local -r cert_file="${cert_dir}/${PRIVATE_CA_CRT_NAME}"
  jq -r '.payload.data' "${payload_file}" | base64 -d > "${cert_file}"
  chmod 444 "${cert_file}"
  rm "${payload_file}"
}

# Create a containerd host config file (using containerd hostpath configuration)
# under ${CONTAINERD_CRI_REGISTRY_HOSTPATH_CONFIG_ROOT}/${domain}
# It expects two arguments:
# - domain
# - CA certificate path
function add-containerd-cri-hostpath-registry-private-ca() {
  local -r domain="${1:-}"
  if [[ -z "${domain}" ]]; then
    echo "Domain must be specified"
    return 1
  fi
  local -r ca_cert_path="${2:-}"
  if [[ -z "${ca_cert_path}" ]]; then
    echo "CA certificate path must be specified"
    return 1
  fi

  local -r host_config_dir="${CONTAINERD_CRI_REGISTRY_HOSTPATH_CONFIG_ROOT}/${domain}"
  mkdir -p "${host_config_dir}"
  local -r host_config_path="${host_config_dir}/hosts.toml"
  cat > "${host_config_path}" <<EOF
server = "https://${domain}"

[host."https://${domain}"]
  ca = "${ca_cert_path}"
EOF
  chmod 644 "${host_config_path}"
}

function configure-containerd-customization {
  echo "Configuring private CA for container registries using GSM"
  if [[ -n "${CONTAINERD_PRIVATE_CA_GSM_CERT:-}" ]]; then
    mkdir -p "${CONTAINERD_CRI_REGISTRY_HOSTPATH_CERTS_ROOT}"

    # Config must be in a predefined JSON format.
    # See go/gke-private-ca-kubenv-source.
    local cert_url cert_dir
    echo "${CONTAINERD_PRIVATE_CA_GSM_CERT}" | jq -c '.secret_configs[]' | while read -r config; do
      cert_url="$(echo "${config}" | jq -r '.secret_url')"
      cert_dir="${CONTAINERD_CRI_REGISTRY_HOSTPATH_CERTS_ROOT}/${cert_url}"
      mkdir -p "${cert_dir}"
      if ! install-gsm-certificate "${cert_url}" "${cert_dir}"; then
        # Certificate installation failed, no need to write containerd config.
        echo "Failed to install certificate \"${cert_url}\""
        continue
      fi
      echo "Installed certificate \"${cert_url}\""
      echo "${config}" | jq -r '.fqdns[]' | while read -r domain; do
        add-containerd-cri-hostpath-registry-private-ca "${domain}" "${cert_dir}/${PRIVATE_CA_CRT_NAME}"
      done
    done
  fi
}

# If your new containerd feature uses CRI registry hostpath config model,
# update this function to include it.
function use-containerd-cri-registry-hostpath {
  if [[ -n "${CONTAINERD_PRIVATE_CA_GSM_CERT:-}" || "${CONTAINERD_REGISTRY_HOSTS_ENABLED:-false}" == "true" ]]; then
    echo "true"
    return
  fi
  echo "false"
}

# add-containerd-cri-hostpath-registry-mirrors receives a domain and a variable
# number of mirrors as args. If the hosts.toml file already exists
# for given domain, it just appends to it.
function add-containerd-cri-hostpath-registry-mirrors {
  local -r domain="${1:-}"
  if [[ -z "${domain}" ]]; then
    echo "Mirror must be passed"
    return 1
  fi
  shift

  local -r host_config_dir="${CONTAINERD_CRI_REGISTRY_HOSTPATH_CONFIG_ROOT}/${domain}"
  mkdir -p "${host_config_dir}"
  local -r host_config_path="${host_config_dir}/hosts.toml"
  if [[ ! -e "${host_config_path}" ]]; then
    cat > "${host_config_path}" <<EOF
server = "https://${domain}"

EOF
    chmod 644 "${host_config_path}"
  fi
  local mirror
  while (( "$#" )); do
    mirror="${1}"
    cat >> "${host_config_path}" <<EOF
[host."https://${mirror}"]
  capabilities = ["pull", "resolve"]
EOF
    shift
  done
}

function gke-setup-containerd-memlock-limit {
  local -r CONTAINERD_DROP_IN="/etc/systemd/system/containerd.service.d"
  if [[ "${SET_MEMLOCK_LIMIT_UNLIMITED:-}" == "true" ]]; then
      echo "Generating containerd system drop in config for memlock limit"
      local -r memlock_limit_path="${CONTAINERD_DROP_IN}/30-LimitMEMLOCK-infinity.conf"
      cat >> "${memlock_limit_path}" <<EOF
[Service]
LimitMEMLOCK=infinity
EOF
    fi
}

function gke-setup-containerd-gcfs-dependency {
  local -r CONTAINERD_DROP_IN="/etc/systemd/system/containerd.service.d"
  if [[ "${ENABLE_GCFS:-}" == "true" ]]; then
    local -r gcfs_require_path="${CONTAINERD_DROP_IN}/40-RequireGCFS-snapshotter.conf"
    echo "Generating containerd system drop in config for gcfs-snapshotter requirement (ENABLE_GCFS=true)"
    cat >> "${gcfs_require_path}" <<EOF
[Unit]
Requires=gcfs-snapshotter.service
EOF
  fi
}

function gke-setup-containerd-nofile-infinity {
  local -r CONTAINERD_DROP_IN="/etc/systemd/system/containerd.service.d"
  local -r nofile_limit_path="${CONTAINERD_DROP_IN}/50-LimitNOFILE-infinity.conf"
  echo "Generating containerd system drop in config for nofile limit"
  cat >> "${nofile_limit_path}" <<EOF
[Service]
LimitNOFILE=infinity
EOF
}

function gke-setup-containerd-drop-in-systemd-config {
  local -r CONTAINERD_DROP_IN="/etc/systemd/system/containerd.service.d"
  mkdir -p "${CONTAINERD_DROP_IN}"
  gke-setup-containerd-gcfs-dependency
  gke-setup-containerd-memlock-limit
  gke-setup-containerd-nofile-infinity
}

function gke-setup-containerd {
  local -r CONTAINERD_HOME="/home/containerd"
  mkdir -p "${CONTAINERD_HOME}"

  echo "Generating containerd config"
  local -r config_path="${CONTAINERD_CONFIG_FILE:-"/etc/containerd/config.toml"}"
  mkdir -p "${CONTAINERD_CONFIG_ROOT}"
  local cni_template_path="${CONTAINERD_HOME}/cni.template"
  _gke_cni_template > "${cni_template_path}"
  if [[ "${KUBERNETES_MASTER:-}" != "true" ]]; then
    if [[ "${NETWORK_POLICY_PROVIDER:-"none"}" != "none" || "${ENABLE_NETD:-}" == "true" ]]; then
      # Use Kubernetes cni daemonset on node if network policy provider is specified
      # or netd is enabled.
      cni_template_path=""
    fi
  fi
  # Use systemd cgroup driver when running on cgroupv2
  local systemdCgroup="false"
  if [[ "${CGROUP_CONFIG-}" == "cgroup2fs" ]]; then
    systemdCgroup="true"
  fi
  # Reuse docker group for containerd.
  local -r containerd_gid="$(grep -m 1 ^docker: /etc/group | cut -d: -f 3)"
  # Create directories for cdi and give the correct permissions
  local -r CDI_ETC_HOME="/etc/cdi"
  mkdir -p "${CDI_ETC_HOME}"
  chown root:root "${CDI_ETC_HOME}"
  chmod 700 "${CDI_ETC_HOME}"
  local -r CDI_VAR_HOME="/var/run/cdi"
  mkdir -p "${CDI_VAR_HOME}"
  chown root:root "${CDI_VAR_HOME}"
  chmod 700 "${CDI_VAR_HOME}"

  cat > "${config_path}" <<EOF
version = 2
required_plugins = ["io.containerd.grpc.v1.cri"]
# Kubernetes doesn't use containerd restart manager.
disabled_plugins = ["io.containerd.internal.v1.restart"]
oom_score = -999

[debug]
  level = "${CONTAINERD_LOG_LEVEL:-"info"}"

[grpc]
  gid = ${containerd_gid}

[plugins."io.containerd.grpc.v1.cri"]
  enable_cdi = true
  stream_server_address = "127.0.0.1"
  max_container_log_line_size = ${CONTAINERD_MAX_CONTAINER_LOG_LINE:-262144}
  sandbox_image = "${KUBE_DOCKER_REGISTRY}/${GKE_CONTAINERD_INFRA_CONTAINER}"
  image_pull_progress_timeout = "5m"
EOF

  if [[ "${ENABLE_CONTAINERD_HUGETLB_CONTROLLER:-}" == "true" ]]; then
    cat >> "${config_path}" <<EOF
  disable_hugetlb_controller = false
EOF
  fi

  cat >> "${config_path}" <<EOF
[plugins."io.containerd.grpc.v1.cri".cni]
  bin_dir = "${KUBE_HOME}/bin"
  conf_dir = "/etc/cni/net.d"
  conf_template = "${cni_template_path}"
[plugins."io.containerd.grpc.v1.cri".containerd.runtimes.runc.options]
  SystemdCgroup = ${systemdCgroup}
EOF

  # Setup mirrors based on the CRI registry config model
  if [[ "$(use-containerd-cri-registry-hostpath)" == "true" ]]; then
    cat >> "${config_path}" <<EOF
# IMPORTANT: CRI REGISTRY CONFIGURATION WAS SWITCHED TO THE HOSTPATH CONFIG MODEL.
# IF YOU'RE CUSTOMIZING CONTAINERD CONFIG PLEASE ENSURE YOU USE THE NEW MODEL.
[plugins."io.containerd.grpc.v1.cri".registry]
  config_path = "${CONTAINERD_CRI_REGISTRY_HOSTPATH_CONFIG_ROOT}"
EOF
    add-containerd-cri-hostpath-registry-mirrors "docker.io" \
      "mirror.gcr.io" "registry-1.docker.io"
  else
    cat >> "${config_path}" <<EOF
[plugins."io.containerd.grpc.v1.cri".registry.mirrors."docker.io"]
  endpoint = ["https://mirror.gcr.io","https://registry-1.docker.io"]
EOF
  fi

  configure-containerd-customization

  if [[ "${ENABLE_CONTAINERD_METRICS:-}" == "true" ]]; then
    cat >> "${config_path}" <<EOF
[metrics]
 address = "127.0.0.1:1338"
EOF
  fi

  if [[ "${ENABLE_CONTAINERD_NRI:-}" == "true" ]]; then
    cat >> "${config_path}" <<EOF
[plugins."io.containerd.nri.v1.nri"]
 disable = false
 disable_connections = false
 plugin_config_path = "/etc/nri/conf.d"
 plugin_path = "/home/kubernetes/nri/plugins"
 plugin_registration_timeout = "5s"
 plugin_request_timeout = "5s"
 socket_path = "/var/run/nri/nri.sock"
EOF
  fi

  if [[ "${ENABLE_GCFS:-}" == "true" ]]; then
    gke-setup-gcfs
    local snapshotter="gcfs"

    # ENABLE_RIPTIDE_IMAGE_PRELOADING is a flag specifically used for the preloading bootstrap service
    # in preloader_script_v2.sh. When this flag is enabled preloading will occur normally, hence why
    # the default overlayfs snapshotter is used, but during the preloading process unpacking for both
    # gcfs and overlayfs will occur.
    if [[ "${ENABLE_RIPTIDE_IMAGE_PRELOADING:-false}" == "true" ]]; then
      snapshotter="overlayfs"
    fi
    cat >> "${config_path}" <<EOF
[plugins."io.containerd.grpc.v1.cri".containerd]
  default_runtime_name = "runc"
  snapshotter = "${snapshotter}"
  disable_snapshot_annotations = false
  discard_unpacked_layers = true
[plugins."io.containerd.grpc.v1.cri".containerd.runtimes.runc]
  runtime_type = "io.containerd.runc.v2"
[proxy_plugins]
  [proxy_plugins.gcfs]
    type = "snapshot"
    address = "/run/containerd-gcfs-grpc/containerd-gcfs-grpc.sock"
EOF
  else
  cat >> "${config_path}" <<EOF
[plugins."io.containerd.grpc.v1.cri".containerd]
  default_runtime_name = "runc"
  discard_unpacked_layers = true
[plugins."io.containerd.grpc.v1.cri".containerd.runtimes.runc]
  runtime_type = "io.containerd.runc.v2"
EOF
  fi

  local -r sandbox_root="${CONTAINERD_SANDBOX_RUNTIME_ROOT:-"/run/containerd/runsc"}"
  # shim_config_path is the path of gvisor-containerd-shim config file.
  local -r shim_config_path="${GVISOR_CONTAINERD_SHIM_CONFIG_PATH:-"${sandbox_root}/config.toml"}"

  if [[ -n "${CONTAINERD_SANDBOX_RUNTIME_HANDLER:-}" ]]; then
    # Setup opt directory for containerd plugins.
    local -r containerd_opt_path="${CONTAINERD_HOME}/opt/containerd"
    mkdir -p "${containerd_opt_path}"
    mkdir -p "${containerd_opt_path}/bin"
    mkdir -p "${containerd_opt_path}/lib"

    local -r containerd_sandbox_pod_annotations=${CONTAINERD_SANDBOX_POD_ANNOTATIONS:-'"dev.gvisor.*"'}
    cat >> "${config_path}" <<EOF
[plugins."io.containerd.grpc.v1.cri".containerd.runtimes.${CONTAINERD_SANDBOX_RUNTIME_HANDLER}]
  runtime_type = "${CONTAINERD_SANDBOX_RUNTIME_TYPE:-}"
  pod_annotations = [ ${containerd_sandbox_pod_annotations} ]
[plugins."io.containerd.grpc.v1.cri".containerd.runtimes.${CONTAINERD_SANDBOX_RUNTIME_HANDLER}.options]
  TypeUrl = "io.containerd.runsc.v1.options"
  ConfigPath = "${shim_config_path}"

[plugins."io.containerd.internal.v1.opt"]
  path = "${containerd_opt_path}"
EOF
  fi
  chmod 644 "${config_path}"

  local -r gvisor_platform="${GVISOR_PLATFORM:-"ptrace"}"

  # If we can install via the installer container, do so.
  # The installation container:
  # 1. Installs the requred binaries (runsc and containerd-shim) to the expected
  # directories (under /home/containerd/...).
  # 2. Writes the required gVisor config.toml file to /run/containerd/runsc/config.toml.
  #
  # We do this here so that we can dynamically load versions of gVisor by downloading the
  # passed container image. The installation mounts root and runs as a priviledged container
  # so that it can write binaries and files to the host's file system and inspect the
  # system configuration so that it can use flags in specific contexts (e.g. Is this an
  # x86 machine? If so, set the 'core-tags' flag to mitigate side-channel attacks.)
  # Note that 'ctr' will not pull the image itself as that is done in config.sh.
  #
  # See: http://google3/cloud/kubernetes/distro/containers/gvisor
  if [[ -n "${GVISOR_INSTALLER_IMAGE_HASH:-}" ]]; then
    local -r installer_image_hash="${GVISOR_INSTALLER_IMAGE_HASH:-}"
    local -r installer_image="${KUBE_DOCKER_REGISTRY}/gke-gvisor-installer@sha256:${installer_image_hash}"
    ctr -n k8s.io run --rm --mount=type=bind,src=/,dst=/host,options=rbind:rw --privileged "${installer_image}" gvisor-installer
  # Generate gvisor containerd shim config
  elif [[ -n "${GVISOR_CONTAINERD_SHIM_PATH:-}" ]]; then
    cp "${GVISOR_CONTAINERD_SHIM_PATH}" "${containerd_opt_path}/bin"
    # gvisor_platform is the platform to use for gvisor.
    local -r gvisor_net_raw="${GVISOR_NET_RAW:-"true"}"
    local -r gvisor_seccomp="${GVISOR_SECCOMP:-"true"}"
    local -r gvisor_core_tags="${GVISOR_CORE_TAGS:-"false"}"
    local -r gvisor_reproduce_nftables="${GVISOR_REPRODUCE_NFTABLES:-"false"}"
    mkdir -p "${sandbox_root}"
    cat > "${shim_config_path}" <<EOF
binary_name = "${CONTAINERD_SANDBOX_RUNTIME_ENGINE:-}"
root = "${sandbox_root}"
[runsc_config]
  platform = "${gvisor_platform}"
  net-raw = "${gvisor_net_raw}"
  oci-seccomp = "${gvisor_seccomp}"
  systemd-cgroup = "${systemdCgroup}"
  enable-core-tags = "${gvisor_core_tags}"
  reproduce-nftables = "${gvisor_reproduce_nftables}"
EOF
    if [[ -n "${GVISOR_METRIC_SERVER:-}" ]]; then
      echo "  metric-server = \"${GVISOR_METRIC_SERVER}\"" >> "${shim_config_path}"
    fi
    if [[ -n "${GVISOR_HOST_SETTINGS:-}" ]]; then
      echo "  host-settings = \"${GVISOR_HOST_SETTINGS}\"" >> "${shim_config_path}"
    fi
  fi

  if [[ "${gvisor_platform}" == "xemu" ]]; then
    # COS versions cos-97-16919-29-21 and after contain XEMU in the base
    # image.
    modprobe xemu
  fi

  if [[ "${ENABLE_RIPTIDE_IMAGE_PRELOADING:-false}" == "false" ]]; then
    # Mount /home/containerd as readonly to avoid security issues.
    mount --bind -o ro,exec "${CONTAINERD_HOME}" "${CONTAINERD_HOME}"
  fi

  # Invoke the installable gke-containerd-config before restarting containerd
  # Currently it configures hosts.d and certs.d for containerd.
  if installable-component-exists "gke-containerd-config"; then
    process-installables "gke-containerd-config"
  fi

  echo "Restart containerd to load the config change"
  systemctl daemon-reload
  systemctl restart containerd
}

# Manipulate SMT settings for the node. GKE Sandbox by default
# disables SMT for vulnerable nodes.
function configure-smt {
  declare -r smt_op="${GVISOR_ENABLE_SMT:-}"
  declare -r smt_path="/sys/devices/system/cpu/smt/control"
  local smt_state
  smt_state=$(cat ${smt_path})
  echo "SMT in initial state: ${smt_state}"
  if [[ "${smt_op}" == "true" ]]; then
    echo "Enabling SMT for node."
    echo "on" > "${smt_path}" || true
  elif [[ "${smt_op}" == "false" ]]; then
    echo "Disabling SMT for node."
    echo "off" > "${smt_path}" || true
  fi
  smt_state=$(cat ${smt_path})
  echo "SMT in final state: ${smt_state}"
}

# If we specify GKE_ADDON_REGISTRY_OVERRIDE, it will replace all occurrences
# of 'gke.gcr.io', with the specified value in all the manifests.
# This is useful when running in test or staging, example:
# gke.gcr.io -> eu.gcr.io/gke-release-staging
function setup-gke-addon-registry {
  local -r manifests_dir="${KUBE_HOME}/kube-manifests/kubernetes/gci-trusty"
  local -r gke_addon_registry_override="${GKE_ADDON_REGISTRY_OVERRIDE:-}"
  if [[ -n $gke_addon_registry_override ]] ; then
    # some .manifest files are in yaml format, while others are in json
    find "${manifests_dir}" \( -name \*.yaml -or -name \*.yaml.in -or -name \*.manifest \) -print0 | \
      xargs -0 sed -ri "s@(image:\s.*)gke.gcr.io@\1${gke_addon_registry_override}@"
    find "${manifests_dir}" \( -name \*.manifest -or -name \*.json \) -print0 | \
      xargs -0 sed -ri "s@(image\":\s+\")gke.gcr.io@\1${gke_addon_registry_override}@"
  fi
}

# Configure node-problem-detector flags.
#
# This function expects no arguments. It currently configures NPD to operate as
# a stand-alone service on a COS/GCI image.
#
# This function
#   - is a no-op, if NODE_PROBLEM_DETECTOR_CUSTOM_FLAGS is already set (on
#     instance metadata). (Note that it is not recommended to set
#     NODE_PROBLEM_DETECTOR_CUSTOM_FLAGS on instance metadata from google3).
#   - sets NODE_PROBLEM_DETECTOR_CUSTOM_FLAGS with the flags to be used by NPD
#     in function start-node-problem-detector, otherwise.
function gke-configure-node-problem-detector {
  local flags="${NODE_PROBLEM_DETECTOR_CUSTOM_FLAGS:-}"
  if [[ -n "${flags}" ]]; then
    return
  fi

  local -r km_config="${KUBE_HOME}/node-problem-detector/config/kernel-monitor.json"
  # TODO(random-liu): Handle this for alternative container runtime.
  local -r dm_config="${KUBE_HOME}/node-problem-detector/config/docker-monitor.json"
  local -r sm_config="${KUBE_HOME}/node-problem-detector/config/systemd-monitor.json"

  local -r custom_km_config="${KUBE_HOME}/node-problem-detector/config/kernel-monitor-counter.json"
  local -r custom_sm_config="${KUBE_HOME}/node-problem-detector/config/systemd-monitor-counter.json"

  local -r sd_exporter_config="${KUBE_HOME}/node-problem-detector/config/exporter/stackdriver-exporter.json"

  # TODO(b/235657451): add "net-cgroup-system-stats-monitor.json"
  local -r system_stats_monitor="${KUBE_HOME}/node-problem-detector/config/system-stats-monitor.json"

  local custom_plugin_monitors="${custom_km_config},${custom_sm_config}"

  gke-configure-npd-custom-plugins
  if [[ -n "${GKE_NPD_CUSTOM_PLUGINS_CONFIG:-}" ]]; then
    custom_plugin_monitors+=",${GKE_NPD_CUSTOM_PLUGINS_CONFIG}"
  fi

  local node_registration_checker_config=",${KUBE_HOME}/npd-custom-plugins/configs/node-registration-checker-monitor.json"

  # Configure private CA plugin
  if [[ -n "${CONTAINERD_PRIVATE_CA_GSM_CERT:-}" ]]; then
    local -r private_ca_monitor_config=",${KUBE_HOME}/npd-custom-plugins/configs/private-ca-installation-monitor.json"
  fi

  local -r local_ssd_config="${KUBE_HOME}/npd-custom-plugins/configs/local-ssd-monitor.json"
  local -r node_startup_monitor="${KUBE_HOME}/npd-custom-plugins/configs/node-startup-monitor.json"
  local -r oom_monitor="${KUBE_HOME}/npd-custom-plugins/configs/oom-monitor.json"

  flags="${NPD_TEST_LOG_LEVEL:-"--v=2"} ${NPD_TEST_ARGS:-}"
  flags+=" --logtostderr"
  flags+=" --config.system-log-monitor=${km_config},${dm_config},${sm_config},${local_ssd_config},${node_startup_monitor},${oom_monitor}${node_registration_checker_config:-}${private_ca_monitor_config:-}"
  flags+=" --config.system-stats-monitor=${system_stats_monitor}"
  flags+=" --config.custom-plugin-monitor=${custom_plugin_monitors}"
  flags+=" --exporter.stackdriver=${sd_exporter_config}"
  local -r npd_port=${NODE_PROBLEM_DETECTOR_PORT:-20256}
  flags+=" --port=${npd_port}"
  if [[ -n "${EXTRA_NPD_ARGS:-}" ]]; then
    flags+=" ${EXTRA_NPD_ARGS}"
  fi

  NODE_PROBLEM_DETECTOR_CUSTOM_FLAGS="${flags}"
}

# Configure NPD custom plugins.
#
# This function expects no arguments.
#
# This function configures NPD custom plugins and sets
# GKE_NPD_CUSTOM_PLUGINS_CONFIG with the NPD flags needed to enable the plugins.
function gke-configure-npd-custom-plugins {
  local -r config_dir="${KUBE_HOME}/npd-custom-plugins/configs"

  # Configure sysctl monitor.
  GKE_NPD_CUSTOM_PLUGINS_CONFIG="${config_dir}/sysctl-monitor.json"

  # Enable containerd 1.x deprecation checkers
  if [[ -n "${CONTAINERD_DEPRECATION_CHECKER:-}" ]]; then
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/containerd-deprecation-config-auths.json"
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/containerd-deprecation-config-configs.json"
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/containerd-deprecation-config-mirrors.json"
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/containerd-deprecation-cri-v1alpha2.json"
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/containerd-deprecation-others.json"
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/containerd-deprecation-schema-v1-image.json"
  fi

  # the two json configs only includes gcfs-snapshotter and gcfsd service for now
  if [[ "${ENABLE_GCFS:-}" == "true" ]]; then
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/systemd-monitor-health.json,${config_dir}/systemd-monitor-restart.json,${config_dir}/gcfs-snapshotter-missing-layer-monitor.json,${config_dir}/secondary-boot-disk-missing-layer.json"
  fi

  # Configure detect reboot monitor
  if [[ "${ENABLE_BEST_EFFORT_NODE_REBOOT:-}" == "true" ]]; then
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/node-reboot-monitor.json"
  fi

  # Configure EK VM monitor
  if [[ "${ENABLE_EK_NPD_PLUGINS:-}" == "true" ]]; then
    GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/ek-node-checker/balloon-pod-checker.json,${config_dir}/ek-node-checker/cgroups-cpu-checker.json,${config_dir}/ek-node-checker/cpu-and-ram-balloon-checker.json,${config_dir}/ek-node-checker/cpu-and-ram-balloon-monitor.json,${config_dir}/ek-node-checker/unsupported-configs-checker.json"
  fi

  GKE_NPD_CUSTOM_PLUGINS_CONFIG+=",${config_dir}/swap-monitor.json,${config_dir}/fs-readonly-monitor.json,${config_dir}/fs-capacity-monitor.json,${config_dir}/kubelet-monitor.json,${config_dir}/resource-monitor.json,${config_dir}/dpv2-migration-cni-checker.json,${config_dir}/unsupported-ebpf-checker.json"
}

# Set up GCFS daemons.
function gke-setup-gcfs {
  # Write the systemd service file for GCFS FUSE client.
  local -r gcfsd_mnt_dir="/run/gcfsd/mnt"
  local -r layer_cache_dir="/var/lib/containerd/io.containerd.snapshotter.v1.gcfs/snapshotter/layers"
  local -r images_in_use_db_path="/var/lib/containerd/io.containerd.snapshotter.v1.gcfs/gcfsd/images_in_use.db"

  local each_cache_size
  local gcfs_cache_size_flag
  if [[ -z "${GCFSD_CACHE_SIZE_MIB:-}" ]]; then
    gcfs_cache_size_flag=""
  else
    # GCFSD maintains two caches, each being allocated half of GCFSD_CACHE_SIZE_MIB
    each_cache_size=$((${GCFSD_CACHE_SIZE_MIB:-} / 2))
    gcfs_cache_size_flag="--max_content_cache_size_mb=${each_cache_size} --max_large_files_cache_size_mb=${each_cache_size}"
  fi

  local gcfs_layer_caching_flag=""
  if [[ "${ENABLE_GCFS_LAYER_CACHING:-false}" == "true" ]]; then
    gcfs_layer_caching_flag="--layer_cache_dir=${layer_cache_dir}"
  fi

  local client_version_flag=""
  if [[ -n "${KUBELET_VERSION:-}" ]]; then
    client_version_flag="--client_version=\"${KUBELET_VERSION}\""
  fi

  local secondary_boot_disk_mount_points_flag=""
  if [[ -n "${SECONDARY_BOOT_DISKS:-}" ]]; then
    secondary_boot_disk_mount_points_flag="--secondary-disk-mount-points=${SECONDARY_BOOT_DISKS}"
  fi

  local secondary_boot_data_disk_mount_points_flag=""
  if [[ -n "${SECONDARY_BOOT_DATA_DISKS:-}" ]]; then
    secondary_boot_data_disk_mount_points_flag="--secondary-data-disk-mount-points=${SECONDARY_BOOT_DATA_DISKS}"
  fi

  local enable_metric_exporter_flag=""
  if [[ "${ENABLE_RIPTIDE_IMAGE_PRELOADING:-false}" == "true" ]]; then
    enable_metric_exporter_flag="--enable-metric-exporter=false"
  fi

  # gcfsd read-ahead parameters
  local enable_single_flighting="--enable_single_flighting=true"
  local read_ahead_max_blocks="--read_ahead_max_blocks=10"
  local read_ahead_cache_size_ratio="--read_ahead_cache_size_ratio=0.1"

  # gcfsd read-ahead flag
  local gcfs_read_ahead_flag="${enable_single_flighting} ${read_ahead_max_blocks} ${read_ahead_cache_size_ratio}"

  # Enable gcfsd to use node P4SA to call Google APIs.
  if [[ -n "${GCFSD_ADC_CONFIG:-}" ]]; then
    local gcfsd_application_default_credentials_config_path="${KUBE_HOME}/gcfsd_application_default_credentials.json"
    echo "$GCFSD_ADC_CONFIG" > "${gcfsd_application_default_credentials_config_path}"
  fi

  # Enable gcfs-snapshotter to use node P4SA to call Google APIs.
  if [[ -n "${GCFS_SNAPSHOTTER_ADC_CONFIG:-}" ]]; then
    local gcfs_snapshotter_application_default_credentials_config_path="${KUBE_HOME}/gcfs_snaphotter_application_default_credentials.json"
    echo "$GCFS_SNAPSHOTTER_ADC_CONFIG" > "${gcfs_snapshotter_application_default_credentials_config_path}"
  fi

  cat <<EOF >/etc/systemd/system/gcfsd.service
# Systemd configuration for Google Container File System service
[Unit]
Description=Google Container File System service
After=network.target
[Service]
Type=notify
LimitNOFILE=infinity
# More aggressive Go garbage collection setting (go/fast/19).
Environment=GOGC=10
EOF

  if [[ -n "${GCFSD_ADC_CONFIG:-}" ]]; then
  # Set GCFSD_METRICS_ADC_CONFIG_PATH instead of GOOGLE_APPLICATION_CREDENTIALS
  # so that the node p4sa is only used for metrics. See go/omg93012-scratch
  cat <<EOF >>/etc/systemd/system/gcfsd.service
Environment="GCFSD_METRICS_ADC_CONFIG_PATH=${gcfsd_application_default_credentials_config_path}"
EOF
  fi

  local gcfsd_bin="gcfsd"
  if [[ "${ENABLE_GCFS_V2_API:-false}" == "true" ]]; then
    gcfsd_bin="gcfsd-v2"
  fi

  cat <<EOF >>/etc/systemd/system/gcfsd.service
ExecStartPre=-/bin/umount -f ${gcfsd_mnt_dir}
ExecStartPre=/bin/mkdir -p ${gcfsd_mnt_dir}
ExecStartPre=/bin/mkdir -p ${layer_cache_dir}
ExecStartPre=/bin/mkdir -p $(dirname ${images_in_use_db_path})
ExecStart=${KUBE_HOME}/bin/${gcfsd_bin} --mount_point=${gcfsd_mnt_dir} ${gcfs_cache_size_flag} ${gcfs_layer_caching_flag} --images_in_use_db_path=${images_in_use_db_path} --enable_pull_secret_keychain --client_name=GKE ${client_version_flag} ${gcfs_read_ahead_flag}
ExecStop=-/bin/umount -f ${gcfsd_mnt_dir}
RuntimeDirectory=gcfsd
Restart=on-failure
RestartSec=10
[Install]
WantedBy=multi-user.target
EOF

  # Write the configuration file for GCFS snapshotter.
  # An empty file would work for now.
  mkdir -p /etc/containerd-gcfs-grpc
  touch /etc/containerd-gcfs-grpc/config.toml
  # Write the systemd service file for GCFS snapshotter
  cat <<EOF >/etc/systemd/system/gcfs-snapshotter.service
# Systemd configuration for Google Container File System snapshotter
[Unit]
Description=GCFS snapshotter
After=network.target
After=gcfsd.service
Before=containerd.service
Wants=gcfsd.service
# Disable restart rate limiting
StartLimitIntervalSec=0
[Service]
Type=notify
Environment=HOME=/root
EOF

  if [[ -n "${GCFS_SNAPSHOTTER_ADC_CONFIG:-}" ]]; then
  # Set GCFS_SNAPSHOTTER_METRICS_ADC_CONFIG_PATH instead of GOOGLE_APPLICATION_CREDENTIALS
  # so that the node p4sa is only used for metrics. See go/omg93012-scratch
  cat <<EOF >>/etc/systemd/system/gcfs-snapshotter.service
Environment="GCFS_SNAPSHOTTER_METRICS_ADC_CONFIG_PATH=${gcfs_snapshotter_application_default_credentials_config_path}"
EOF
  fi

  local enable_v2_api_flag=""
  if [[ "${ENABLE_GCFS_V2_API:-false}" == "true" ]]; then
    enable_v2_api_flag="--enable-v2"
  fi

  cat <<EOF >>/etc/systemd/system/gcfs-snapshotter.service
ExecStart=${KUBE_HOME}/bin/containerd-gcfs-grpc --log-level=info --config=/etc/containerd-gcfs-grpc/config.toml --enable-image-proxy-keychain-client ${secondary_boot_disk_mount_points_flag} ${secondary_boot_data_disk_mount_points_flag} --disable-duplicate-layer-support=false ${enable_metric_exporter_flag} ${enable_v2_api_flag}
Restart=always
RestartSec=1
[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload

  if [[ "${ENABLE_RIPTIDE_IMAGE_PRELOADING:-false}" == "false" ]]; then
    # systemctl will block until gcfsd exits with error or sends a signal via sd_notify.
    # If gcfsd exits with an error, gcfsd will continue to be restarted in the background, however
    # we will continue with gcfs-snapshotter startup and not wait for gcfsd.
    # For new nodes, this will cause gcfs-snapshotter to fallback to default image pulling until
    # gcfsd becomes available. In a reboot case, if snapshots were previously pulled via gcfsd,
    # then they will fail to be loaded until gcfsd becomes available.
    systemctl start gcfsd.service || echo "WARNING: gcfsd.service failed (ret=$?), continuing."
  fi
  systemctl start gcfs-snapshotter.service
}

function gke-create-gpu-config {
  local -r gpu_config_file="/etc/nvidia/gpu_config.json"
  mkdir -p "$(dirname "${gpu_config_file}")"
  local -r dir="${KUBE_HOME}/kube-manifests/kubernetes/gci-trusty/gpu"

  local gpu_partition_size=""
  if [ -n "${GPU_PARTITION_SIZE:-}" ]; then
    gpu_partition_size="${GPU_PARTITION_SIZE}"
  fi

  local max_time_shared_clients_per_gpu=""
  if [ -n "${MAX_TIME_SHARED_CLIENTS_PER_GPU:-}" ]; then
      max_time_shared_clients_per_gpu="${MAX_TIME_SHARED_CLIENTS_PER_GPU}"
  fi

  local max_shared_clients_per_gpu=""
  if [ -n "${MAX_SHARED_CLIENTS_PER_GPU:-}" ]; then
      max_shared_clients_per_gpu="${MAX_SHARED_CLIENTS_PER_GPU}"
  fi

  local gpu_sharing_strategy=""
  if [ -n "${GPU_SHARING_STRATEGY:-}" ]; then
      gpu_sharing_strategy="${GPU_SHARING_STRATEGY}"
  fi

  python3 "${dir}/generate-gpu-config.py" \
    --gpu-partition-size="${gpu_partition_size}" \
    --max-time-shared-clients-per-gpu="${max_time_shared_clients_per_gpu}" \
    --max-shared-clients-per-gpu="${max_shared_clients_per_gpu}" \
    --gpu-sharing-strategy="${gpu_sharing_strategy}" \
    --file-path="${gpu_config_file}"

  # Setup all GPUs to EXCLUSIVE mode (https://docs.nvidia.com/deploy/mps/index.html#topic_3_3_1_2).
  # Setup systemd service to start MPS control daemon.
  if [[ "${GPU_SHARING_STRATEGY:-}" == "mps" ]]; then
    cat <<EOF >/etc/systemd/system/nvidia-mps.service
[Unit]
Description=NVIDIA MPS

[Service]
Type=simple
Restart=always
RestartSec=10
RemainAfterExit=yes
ExecStartPre=/home/kubernetes/bin/nvidia/bin/nvidia-smi -c EXCLUSIVE_PROCESS
ExecStart=/bin/bash -c 'PATH=$PATH:/home/kubernetes/bin/nvidia/bin exec nvidia-cuda-mps-control -d'
ExecStop=echo quit | nvidia-cuda-mps-control

[Install]
WantedBy=multi-user.target
EOF

    cat <<EOF >/etc/systemd/system/nvidia-mps.path
[Unit]
Description=NVIDIA MPS path

[Path]
PathExists=/home/kubernetes/bin/nvidia/bin/nvidia-cuda-mps-control
Unit=nvidia-mps.service

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl start nvidia-mps.path
  fi
}

# Configure sshd as required for Autopilot nodes
function gke-configure-autopilot-sshd {
  echo "Reconfiguring sshd for Autopilot"
  echo "${GKE_AUTOPILOT_SSHD_CONFIG}" >> "/etc/ssh/sshd_config"
  systemctl restart sshd
  echo "Restarted sshd"
}

function deploy-kube-scheduler-via-kube-up {
  [[ "${KUBE_SCHEDULER_CRP:-}" != "true" ]]
}

function deploy-kube-controller-manager-via-kube-up {
  [[ "${KUBE_CONTROLLER_MANAGER_CRP:-}" != "true" ]]
}

function generate-token-for-mastertest {
  [[ "${MASTERTEST_TOKEN_ENABLED:-false}" == "true" ]]
}

function configure-auth-provider-gcp {
  registry_domain="$(echo "${KUBE_DOCKER_REGISTRY}" | cut -d '/' -f 1)"
  if [[ "${registry_domain}" != *gcr.io ]] && [[ "${registry_domain}" != *pkg.dev ]]; then
      # Keep in sync with --image-credential-provider-config in cloud/kubernetes/distro/legacy/kube_env.go
      cat > "/etc/srv/kubernetes/cri_auth_config.yaml" << EOF
kind: CredentialProviderConfig
apiVersion: kubelet.config.k8s.io/v1
providers:
  - name: auth-provider-gcp
    apiVersion: credentialprovider.kubelet.k8s.io/v1
    matchImages:
    - "${registry_domain}"
    args:
    - get-credentials
    - --v=3
    defaultCacheDuration: 1m
EOF
      return
  fi
  # Keep in sync with --image-credential-provider-config in cloud/kubernetes/distro/legacy/kube_env.go
  cat > "/etc/srv/kubernetes/cri_auth_config.yaml" << EOF
kind: CredentialProviderConfig
apiVersion: kubelet.config.k8s.io/v1
providers:
  - name: auth-provider-gcp
    apiVersion: credentialprovider.kubelet.k8s.io/v1
    matchImages:
    - "container.cloud.google.com"
    - "gcr.io"
    - "*.gcr.io"
    - "*.pkg.dev"
    args:
    - get-credentials
    - --v=3
    defaultCacheDuration: 1m
EOF
}

# Processes installable artifacts. This respects download restrictions by checking the
# ARTIFACT_DOWNLOAD_RESTRICTED env variable. If downloads are not restricted, the script downloads
# and executes installables. If downloads are restricted, the script ensures that the installables
# have been preloaded and executes them. See installable.py for details.
function process-installables {
  local installable_name="${1:-}"
  local script="${KUBE_BIN}/installable.py"
  # Installables are passed as JSON. Pass an empty map if none have been passed.
  local installables="${RENDERED_INSTALLABLES:-"{}"}"
  local flags=(
    "--installables=${installables}"
    "--component=${installable_name}"
  )
  # Record the proecessed installables so we don't process things twice.
  local preload_info_file="${KUBE_HOME}/preloaded-installables"
  if [[ "${IS_PRELOADER:-}" == "true" ]]; then
    flags+=("--record-file=${preload_info_file}")
    flags+=("--preloader")
  else
    flags+=("--preload-info-file=${preload_info_file}")
    flags+=("--record-file=/tmp/processed-installables")
  fi

  if [[ "${ARTIFACT_DOWNLOAD_RESTRICTED:-}" == "true" ]]; then
    flags+=("--download-restricted")
  fi
  python3 "${script}" "${flags[@]}"
}

# If processing one installable component, first check if it exists in RENDERED_INSTALLABLES map.
function installable-component-exists {
  local installable_name="${1:-}"
  # Installables are passed as Json. Pass an empty map if none have been passed.
  local all_installables="${RENDERED_INSTALLABLES:-"{}"}"
  if [[ -z "${installable_name}" ]]; then
    false
  fi
  if echo "${all_installables}" | jq -e --arg key "${installable_name}" 'has($key)' > /dev/null; then
    true
  else
    false
  fi
}

function create-kcp-admin-kubeconfig {
  ensure-exec-auth-config
  mkdir -p "/etc/srv/kubernetes/local-admin"
  cat > "/etc/srv/kubernetes/local-admin/kubeconfig" << EOF
apiVersion: v1
kind: Config
users:
- name: local-admin
  user:
    exec:
      apiVersion: "client.authentication.k8s.io/v1beta1"
      command: /home/kubernetes/bin/gke-exec-auth-plugin
      args:
      - --mode=alt-token
      - --alt-token-url=${TOKEN_URL}
      - --alt-token-body=${TOKEN_BODY_UNQUOTED}
clusters:
- name: local
  cluster:
    certificate-authority-data: ${CA_CERT}
    server: https://${KUBE_APISERVER_INTERNAL_ADDRESS}:443
    disable-compression: true
contexts:
- context:
    cluster: local
    user: local-admin
  name: local-admin
current-context: local-admin
EOF
}
